package com.example.course_day1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseDay1Application {

    public static void main(String[] args) {
        SpringApplication.run(CourseDay1Application.class, args);
    }
// this is main class
}
