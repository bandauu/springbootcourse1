package com.example.course_day1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
   @GetMapping("/age")
    public String getage(){
        return "my age is 20";
    }
    @GetMapping("/name")
    public String name(){
        return "my name is Nada";
        // in browser : http://localhost:8080/name
    }

    @GetMapping("/check/status")
    public String status(){
        return "everything is ok";

    }
@GetMapping("/health")
    public String health(){
       return "Server health is up and running";
    }
}
